﻿import sqlalchemy as sa
from sqlalchemy.orm import sessionmaker

from users import SqlAlchemyBase, User


def main():
    engine = sa.create_engine("sqlite:///mars_explorer.db", echo=False)
    SqlAlchemyBase.metadata.create_all(engine)

    Session = sessionmaker(bind=engine)
    session = Session()

    colonists = [
        User(
            surname="Scott",
            name="Ridley",
            age=21,
            position="captain",
            speciality="research engineer",
            address="module_1",
            email="scott_chief@mars.org",
            hashed_password="cap",
        ),
        User(
            surname="Watney",
            name="Mark",
            age=32,
            position="engineer",
            speciality="mechanical engineer",
            address="module_2",
            email="watney@mars.org",
            hashed_password="mars",
        ),
        User(
            surname="Johanssen",
            name="Beth",
            age=29,
            position="pilot",
            speciality="pilot",
            address="module_3",
            email="johanssen@mars.org",
            hashed_password="orbit",
        ),
        User(
            surname="Lewis",
            name="Melissa",
            age=34,
            position="commander",
            speciality="geologist",
            address="module_4",
            email="lewis@mars.org",
            hashed_password="ares",
        ),
    ]

    for colonist in colonists:
        if session.query(User).filter(User.email == colonist.email).first() is None:
            session.add(colonist)

    session.commit()

    for user in session.query(User).all():
        print(
            user.id,
            user.surname,
            user.name,
            user.age,
            user.position,
            user.speciality,
            user.address,
            user.email,
        )


if __name__ == "__main__":
    main()
